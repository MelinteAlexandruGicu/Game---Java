package UI;

/*! \interface ClickListener
    \brief Implementeaza notiunea click in joc.

 */
public interface ClickListener {

    public void onClick();
}
